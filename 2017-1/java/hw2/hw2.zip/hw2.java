// HW 172 : Dijkstra's Algorithm
// Name :
// Student ID :

import java.util.*;


class Graph {
	int numofnodes;  // the number of nodes in the graph
	private int[][] CostAdj; // Cost Adjacency matrix
	private int[] d; // d array
	private int[] p; // p array
	int source;	// source node

	final int LargeCost = 999999;

	Graph() { 
		// Graph constructor. 
		numofnodes = 0;
	}

	void Init(int n) { 
		numofnodes = n;
		// now create 2 dimensional array of numofnodes * numofnodes

		CostAdj = new int[numofnodes][numofnodes];

		for(int i = 0; i < numofnodes; i++) {
			for(int j = 0; j < numofnodes; j++) {
				CostAdj[i][j] = LargeCost;
			}
			CostAdj[i][i] = 0;
		}
		// now create d[] and p[]
		d = new int[numofnodes];
		p = new int[numofnodes];

	}



	void Edge(int v1, int v2, int cost) { 
		//	"NEED TO IMPLEMENT" 


	}

	void Dijk(int src) {
		//	"NEED TO IMPLEMENT" 
		source = src;


	}

	void ShowAllPath() {
		//	"NEED TO IMPLEMENT" 



	}

}



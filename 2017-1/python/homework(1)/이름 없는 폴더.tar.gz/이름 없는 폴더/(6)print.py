a = "This is the first sentence. \
This is the second sentence."

print(a)
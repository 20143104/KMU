age = 20
name = 'Swaroop'
print ('{} was {} years old when he wrote this book'.format(name, age))
print ('Why is {} playing with that python?'.format(name))
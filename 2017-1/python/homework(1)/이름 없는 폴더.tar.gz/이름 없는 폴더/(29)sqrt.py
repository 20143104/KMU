from math import sqrt

print ("Square root of 16 is",sqrt(16))
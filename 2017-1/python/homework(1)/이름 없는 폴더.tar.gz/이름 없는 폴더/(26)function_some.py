def some_function():
    pass

some_function()
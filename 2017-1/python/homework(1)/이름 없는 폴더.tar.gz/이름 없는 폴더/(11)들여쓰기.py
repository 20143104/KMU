i=5
 print ('value is' ,i)
print('I repeat, the value is ',i)
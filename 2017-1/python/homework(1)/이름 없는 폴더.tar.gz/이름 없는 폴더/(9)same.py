i=5
print(i)
i=5;
print(i);
i=5; print(i);
i=5; print(i)
def print_max(a,b):
    if a>b :
        print(a,'is maximum')

    elif a==b:
        print(a,'is equal to',b)

    elif a<b:
        print(b,'is maximum')


print_max(3,4)

x=5
y=7

print_max(x,y)
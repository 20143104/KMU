age = 20
name = 'Swaroop'

print ('{0} was {1} years old when he wrote this book'.format(name,age))
print ('Why is {0} playing with that python?'.format(name))
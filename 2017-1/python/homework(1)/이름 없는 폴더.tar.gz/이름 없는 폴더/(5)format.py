print('{0:.3f}'.format(0.1/3))
print('{0:_^11}'.format('hello'))
print('{name} wrote {book}'.format(name = 'Swaroop', book = 'A Byte of python'))
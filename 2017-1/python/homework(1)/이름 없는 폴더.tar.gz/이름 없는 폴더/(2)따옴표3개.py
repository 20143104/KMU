a = '''This is munti-line string. This is the first line.
This is the second line.
"what's your name?," I asked.
He said "Bond, James Bond.
'''

print (a)
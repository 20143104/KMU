a=r"Newslines are indicated by \n"

print(a)
def fun_c(a,b=5,c=10):
    print('a is',a,'and b is',b,'and c is',c)

fun_c(3,7)
fun_c(25,c=24)
fun_c(c=50,a=100)
shoplist = ['apple','mango','carrot','banana']
print(shoplist[::1])
print(shoplist[::2])
print(shoplist[::3])
print(shoplist[::-1])
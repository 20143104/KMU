print("hello world")
print(type("hello world"))
print(u"hello world")
print(type(u"hello world"))
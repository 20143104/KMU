s= input('Enter something--> ')


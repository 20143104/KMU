class Person:
    def say_hi(self):
        print("Hello, how are you")

p=Person()
p.say_hi()
class Person:
    pass

p=Person()

print(p)
import numpy as np

l = np.array([1,2,3,4,5,6,7,8,9])

print(l)

np.random.shuffle(l)

print(l)

import numpy as np;

a = np.array([1,3,0], float)
b = np.array([0,3,2], float)

print (a==b)
print (a<=b)
print (a>2)
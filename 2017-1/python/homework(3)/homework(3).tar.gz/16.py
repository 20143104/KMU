import scipy
print(help(scipy))
import scipy.interpolate

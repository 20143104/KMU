import numpy as np

a= np.array([2,4,6,8],float)
b= np.array([0,0,1,3,2,1], int)

print(a[b])

print(a[[0,0,1,3,2,1]])
import numpy as np

print(np.random.rand(5))

print(np.random.rand(2,3))

print(np.random.rand(6).reshape(2,3))

print(np.random.random())

print(np.random.randint(5,10))

print(np.random.poisson(6.0))

print(np.random.normal(1.5,4.0))

print(np.random.normal())

print(np.random.normal(size=5))
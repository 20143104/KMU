#include<ncurses.h>
#include"main.h"
int main(){
  Tetris t;
  t.play();
  return 0;
}
